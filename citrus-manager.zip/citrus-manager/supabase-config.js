// ✅ 1단계: 아래 두 줄을 Supabase 프로젝트 정보로 교체하세요
//    Supabase → Project Settings → API 에서 복사
const SUPABASE_URL      = 'https://여기에_프로젝트_URL.supabase.co';
const SUPABASE_ANON_KEY = '여기에_anon_public_키_붙여넣기';

// ✅ 2단계: 직원 공용 비밀번호를 원하는 것으로 바꾸세요
const APP_PASSWORD = 'citrus2024';
