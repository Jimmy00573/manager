// ── Supabase 초기화 ──────────────────────────────────────────
const { createClient } = supabase;
const db = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ── 상태 ──────────────────────────────────────────────────────
let currentUser = null;
let farms = [], conts = [], owns = [], scheds = [];
const DAYS = ['일','월','화','수','목','금','토'];

// ── 저장 인디케이터 ───────────────────────────────────────────
function setSave(state) {
  const el = document.getElementById('save-indicator');
  if (!el) return;
  if (state === 'saving') { el.className = 'save-indicator saving'; el.textContent = '● 저장 중...'; }
  else if (state === 'error') { el.className = 'save-indicator error'; el.textContent = '● 저장 실패'; }
  else { el.className = 'save-indicator saved'; el.textContent = '● 저장됨'; }
}

// ── 로그인 / 로그아웃 ─────────────────────────────────────────
async function login() {
  const name = document.getElementById('login-name').value.trim();
  const pw   = document.getElementById('login-pw').value;
  const err  = document.getElementById('login-error');
  err.textContent = '';
  if (!name) { err.textContent = '이름을 입력하세요'; return; }
  if (pw !== APP_PASSWORD) { err.textContent = '비밀번호가 틀렸습니다'; return; }
  currentUser = name;
  localStorage.setItem('citrus_user', name);
  showApp();
}

function logout() {
  if (!confirm('로그아웃 하시겠습니까?')) return;
  currentUser = null;
  localStorage.removeItem('citrus_user');
  location.reload();
}

// ── 앱 초기화 ─────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  const saved = localStorage.getItem('citrus_user');
  if (saved) {
    currentUser = saved;
    showApp();
  } else {
    document.getElementById('loading-screen').style.display = 'none';
    document.getElementById('login-screen').style.display = 'flex';
  }
});

async function showApp() {
  document.getElementById('login-screen').style.display  = 'none';
  document.getElementById('loading-screen').style.display = 'flex';
  await loadAll();
  document.getElementById('loading-screen').style.display = 'none';
  document.getElementById('app').style.display = 'block';
  document.getElementById('user-name').textContent = currentUser;
  setDefaultDates();
  renderAll();
}

// ── 데이터 로드 ───────────────────────────────────────────────
async function loadAll() {
  try {
    const [f, c, o, s] = await Promise.all([
      db.from('farms').select('*').order('created_at'),
      db.from('containers').select('*').order('date', { ascending: false }),
      db.from('own_containers').select('*').order('date', { ascending: false }),
      db.from('schedules').select('*').order('date'),
    ]);
    farms  = f.data || [];
    conts  = c.data || [];
    owns   = o.data || [];
    scheds = s.data || [];
    setSave('saved');
  } catch (e) {
    console.error(e);
    setSave('error');
  }
}

// ── 탭 전환 ───────────────────────────────────────────────────
function showTab(id) {
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === id));
  document.querySelectorAll('.tab-panel').forEach(p => p.classList.toggle('active', p.id === 'tab-' + id));
  if (id === 'dash') renderDash();
}

// ── 날짜 기본값 ───────────────────────────────────────────────
function setDefaultDates() {
  const today = new Date().toISOString().slice(0, 10);
  ['c-date','o-date','s-date'].forEach(id => {
    const el = document.getElementById(id);
    if (el && !el.value) el.value = today;
  });
}

// ── 농가 드롭다운 채우기 ──────────────────────────────────────
function populateFarmSelects() {
  ['c-farm','o-farm','s-farm'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    const val = el.value;
    el.innerHTML = '<option value="">선택</option>';
    farms.forEach(f => el.innerHTML += `<option value="${f.name}">${f.name}</option>`);
    el.value = val;
  });
}

function getFarm(name) { return farms.find(f => f.name === name) || {}; }

function autoFill(prefix) {
  const name = document.getElementById(prefix + '-farm').value;
  const f = getFarm(name);
  const tel  = document.getElementById(prefix + '-tel');
  const addr = document.getElementById(prefix + '-addr');
  if (tel)  tel.value  = f.tel  || '';
  if (addr) addr.value = f.addr || '';
}

// ── 전체 렌더 ─────────────────────────────────────────────────
function renderAll() {
  populateFarmSelects();
  renderDash();
  renderFarm();
  renderCont();
  renderOwn();
  renderSched();
}

// ════════════════════════════════════════════════════
// 현황판
// ════════════════════════════════════════════════════
function getFarmStats(name) {
  const out  = conts.filter(c => c.farm_name === name && c.type === '배출').reduce((s,c) => s + c.qty, 0);
  const pick = conts.filter(c => c.farm_name === name && c.type === '원물수거').reduce((s,c) => s + c.qty, 0);
  const ret  = conts.filter(c => c.farm_name === name && c.type === '잉여회수').reduce((s,c) => s + c.qty, 0);
  const ownLeft = owns.filter(o => o.farm_name === name).reduce((s,o) => s + (o.in_qty - o.out_qty), 0);
  return { out, pick, ret, hold: out - pick - ret, ownLeft };
}

function renderDash() {
  const schedCnt = scheds.filter(s => s.status === '예정').length;
  const doneCnt  = scheds.filter(s => s.status === '완료').length;
  const totalH   = farms.reduce((s, f) => s + getFarmStats(f.name).hold, 0);
  const needN    = farms.filter(f => {
    const st = getFarmStats(f.name);
    return st.hold > 0 || owns.some(o => o.farm_name === f.name && o.consumed === '소진완료' && o.in_qty - o.out_qty > 0);
  }).length;

  document.getElementById('kpi-grid').innerHTML = `
    <div class="kpi-card"><div class="kpi-label">수거 예정</div><div class="kpi-val blue">${schedCnt}</div></div>
    <div class="kpi-card"><div class="kpi-label">수거 완료</div><div class="kpi-val green">${doneCnt}</div></div>
    <div class="kpi-card"><div class="kpi-label">농가 보유 조합 콘테이너</div><div class="kpi-val orange">${totalH}개</div></div>
    <div class="kpi-card"><div class="kpi-label">처리 필요 농가</div><div class="kpi-val ${needN > 0 ? 'red' : 'green'}">${needN}</div></div>
  `;

  const alerts = farms.filter(f => { const st = getFarmStats(f.name); return st.hold > 0 || st.ownLeft > 0; });
  document.getElementById('alert-area').innerHTML = alerts.map(f => {
    const st = getFarmStats(f.name);
    const msgs = [];
    if (st.hold > 0)    msgs.push(`조합 콘테이너 ${st.hold}개 미회수`);
    if (st.ownLeft > 0) msgs.push(`자가 콘테이너 ${st.ownLeft}개 미반납`);
    return `<div class="alert warn">⚠ ${f.name} — ${msgs.join(', ')}</div>`;
  }).join('');

  const tb = document.getElementById('dash-table');
  if (!farms.length) { tb.innerHTML = `<tr class="empty-row"><td colspan="7">농가를 먼저 등록하세요</td></tr>`; return; }
  tb.innerHTML = farms.map(f => {
    const st   = getFarmStats(f.name);
    const need = st.hold > 0 || owns.some(o => o.farm_name === f.name && o.consumed === '소진완료' && o.in_qty - o.out_qty > 0);
    return `<tr>
      <td><strong>${f.name}</strong></td>
      <td>${st.out}</td><td>${st.pick}</td><td>${st.ret}</td>
      <td><span class="badge ${st.hold > 0 ? 'red' : 'green'}">${st.hold}개</span></td>
      <td><span class="badge ${st.ownLeft > 0 ? 'blue' : 'gray'}">${st.ownLeft}개</span></td>
      <td>${need ? '<span class="badge red">처리필요</span>' : '<span class="badge green">정상</span>'}</td>
    </tr>`;
  }).join('');
}

// ════════════════════════════════════════════════════
// 농가 관리
// ════════════════════════════════════════════════════
async function addFarm() {
  const name = document.getElementById('f-name').value.trim();
  if (!name) { alert('농가명을 입력하세요'); return; }
  if (farms.find(f => f.name === name)) { alert('이미 등록된 농가명입니다'); return; }
  setSave('saving');
  const { data, error } = await db.from('farms').insert({
    name,
    tel:          document.getElementById('f-tel').value,
    addr:         document.getElementById('f-addr').value,
    variety:      document.getElementById('f-variety').value,
    expected_qty: parseInt(document.getElementById('f-qty').value) || 0,
    created_by:   currentUser,
  }).select().single();
  if (error) { alert('저장 실패: ' + error.message); setSave('error'); return; }
  farms.push(data);
  ['f-name','f-tel','f-addr','f-variety','f-qty'].forEach(id => document.getElementById(id).value = '');
  setSave('saved');
  populateFarmSelects();
  renderFarm();
  renderDash();
}

function renderFarm() {
  const tb = document.getElementById('farm-table');
  if (!farms.length) { tb.innerHTML = `<tr class="empty-row"><td colspan="8">등록된 농가가 없습니다</td></tr>`; return; }
  tb.innerHTML = farms.map((f, i) => `<tr>
    <td>F-${String(i+1).padStart(3,'0')}</td>
    <td><strong>${f.name}</strong></td>
    <td>${f.tel || '-'}</td>
    <td>${f.addr || '-'}</td>
    <td>${f.variety || '-'}</td>
    <td>${f.expected_qty || '-'}</td>
    <td>${f.created_by || '-'}</td>
    <td><button class="btn danger" onclick="deleteFarm('${f.id}')">삭제</button></td>
  </tr>`).join('');
}

async function deleteFarm(id) {
  if (!confirm('삭제하시겠습니까?')) return;
  setSave('saving');
  await db.from('farms').delete().eq('id', id);
  farms = farms.filter(f => f.id !== id);
  setSave('saved');
  populateFarmSelects();
  renderFarm();
  renderDash();
}

// ════════════════════════════════════════════════════
// 콘테이너 대장
// ════════════════════════════════════════════════════
async function addCont() {
  const date = document.getElementById('c-date').value;
  const farm = document.getElementById('c-farm').value;
  const type = document.getElementById('c-type').value;
  const qty  = parseInt(document.getElementById('c-qty').value) || 0;
  if (!date || !farm || !type || !qty) { alert('날짜, 농가명, 구분, 수량을 입력하세요'); return; }
  setSave('saving');
  const { data, error } = await db.from('containers').insert({
    date, farm_name: farm, type, qty,
    staff:      document.getElementById('c-staff').value,
    car:        document.getElementById('c-car').value,
    note:       document.getElementById('c-note').value,
    created_by: currentUser,
  }).select().single();
  if (error) { alert('저장 실패: ' + error.message); setSave('error'); return; }
  conts.unshift(data);
  ['c-qty','c-staff','c-car','c-note'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('c-type').value = '';
  setSave('saved');
  renderCont();
  renderDash();
}

function renderCont() {
  const tb = document.getElementById('cont-table');
  if (!conts.length) { tb.innerHTML = `<tr class="empty-row"><td colspan="8">기록이 없습니다</td></tr>`; return; }
  const cls = { '배출': 'blue', '원물수거': 'green', '잉여회수': 'gray' };
  tb.innerHTML = conts.map(c => `<tr>
    <td>${c.date}</td>
    <td><strong>${c.farm_name}</strong></td>
    <td><span class="badge ${cls[c.type] || 'gray'}">${c.type}</span></td>
    <td>${c.qty}개</td>
    <td>${c.staff || '-'}</td>
    <td>${c.car || '-'}</td>
    <td>${c.note || '-'}</td>
    <td><button class="btn danger" onclick="deleteCont('${c.id}')">삭제</button></td>
  </tr>`).join('');
}

async function deleteCont(id) {
  if (!confirm('삭제하시겠습니까?')) return;
  setSave('saving');
  await db.from('containers').delete().eq('id', id);
  conts = conts.filter(c => c.id !== id);
  setSave('saved');
  renderCont();
  renderDash();
}

// ════════════════════════════════════════════════════
// 농가 자가 콘테이너
// ════════════════════════════════════════════════════
async function addOwn() {
  const date  = document.getElementById('o-date').value;
  const farm  = document.getElementById('o-farm').value;
  const inQty = parseInt(document.getElementById('o-in').value) || 0;
  if (!date || !farm || !inQty) { alert('반입일자, 농가명, 수량을 입력하세요'); return; }
  setSave('saving');
  const { data, error } = await db.from('own_containers').insert({
    date, farm_name: farm,
    description:   document.getElementById('o-desc').value,
    in_qty:        inQty,
    out_qty:       parseInt(document.getElementById('o-out').value) || 0,
    consumed:      document.getElementById('o-consumed').value,
    return_method: document.getElementById('o-return').value,
    return_date:   document.getElementById('o-rdate').value || null,
    note:          document.getElementById('o-note').value,
    created_by:    currentUser,
  }).select().single();
  if (error) { alert('저장 실패: ' + error.message); setSave('error'); return; }
  owns.unshift(data);
  ['o-in','o-desc','o-out','o-rdate','o-note'].forEach(id => document.getElementById(id).value = '');
  setSave('saved');
  renderOwn();
  renderDash();
}

function renderOwn() {
  const tb = document.getElementById('own-table');
  if (!owns.length) { tb.innerHTML = `<tr class="empty-row"><td colspan="9">기록이 없습니다</td></tr>`; return; }
  const cls = { '소진완료': 'green', '진행중': 'blue', '미소진': 'yellow' };
  tb.innerHTML = owns.map(o => {
    const left = o.in_qty - o.out_qty;
    return `<tr>
      <td>${o.date}</td>
      <td><strong>${o.farm_name}</strong></td>
      <td>${o.description || '-'}</td>
      <td>${o.in_qty}개</td>
      <td>${o.out_qty}개</td>
      <td><span class="badge ${left > 0 ? 'red' : 'green'}">${left}개</span></td>
      <td><span class="badge ${cls[o.consumed] || 'gray'}">${o.consumed}</span></td>
      <td>${o.return_method}</td>
      <td><button class="btn danger" onclick="deleteOwn('${o.id}')">삭제</button></td>
    </tr>`;
  }).join('');
}

async function deleteOwn(id) {
  if (!confirm('삭제하시겠습니까?')) return;
  setSave('saving');
  await db.from('own_containers').delete().eq('id', id);
  owns = owns.filter(o => o.id !== id);
  setSave('saved');
  renderOwn();
  renderDash();
}

// ════════════════════════════════════════════════════
// 수거 일정
// ════════════════════════════════════════════════════
async function addSched() {
  const date = document.getElementById('s-date').value;
  const farm = document.getElementById('s-farm').value;
  if (!date || !farm) { alert('날짜와 농가명을 입력하세요'); return; }
  setSave('saving');
  const { data, error } = await db.from('schedules').insert({
    date, farm_name: farm,
    status:       document.getElementById('s-status').value,
    expected_qty: parseInt(document.getElementById('s-exp').value) || 0,
    actual_qty:   parseInt(document.getElementById('s-act').value) || 0,
    car:          document.getElementById('s-car').value,
    driver:       document.getElementById('s-driver').value,
    note:         document.getElementById('s-note').value,
    created_by:   currentUser,
  }).select().single();
  if (error) { alert('저장 실패: ' + error.message); setSave('error'); return; }
  scheds.push(data);
  scheds.sort((a, b) => a.date > b.date ? 1 : -1);
  ['s-exp','s-act','s-car','s-driver','s-note'].forEach(id => document.getElementById(id).value = '');
  setSave('saved');
  renderSched();
  renderDash();
}

function renderSched() {
  const tb = document.getElementById('sched-table');
  if (!scheds.length) { tb.innerHTML = `<tr class="empty-row"><td colspan="10">일정이 없습니다</td></tr>`; return; }
  const cls = { '예정': 'blue', '완료': 'green', '취소': 'gray', '연기': 'yellow' };
  tb.innerHTML = scheds.map(s => {
    const d = new Date(s.date + 'T00:00:00');
    return `<tr>
      <td>${s.date}</td>
      <td>${DAYS[d.getDay()]}</td>
      <td><strong>${s.farm_name}</strong></td>
      <td><span class="badge ${cls[s.status] || 'gray'}">${s.status}</span></td>
      <td>${s.expected_qty || '-'}</td>
      <td>${s.actual_qty || '-'}</td>
      <td>${s.car || '-'}</td>
      <td>${s.driver || '-'}</td>
      <td>${s.note || '-'}</td>
      <td><button class="btn danger" onclick="deleteSched('${s.id}')">삭제</button></td>
    </tr>`;
  }).join('');
}

async function deleteSched(id) {
  if (!confirm('삭제하시겠습니까?')) return;
  setSave('saving');
  await db.from('schedules').delete().eq('id', id);
  scheds = scheds.filter(s => s.id !== id);
  setSave('saved');
  renderSched();
  renderDash();
}

// ── 엔터키 로그인 ─────────────────────────────────────────────
document.addEventListener('keydown', e => {
  const ls = document.getElementById('login-screen');
  if (e.key === 'Enter' && ls && ls.style.display !== 'none') login();
});
