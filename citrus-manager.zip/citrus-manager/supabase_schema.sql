-- ✅ Supabase SQL Editor에서 이 전체 내용을 복사해서 실행하세요

-- 농가 테이블
CREATE TABLE farms (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL UNIQUE,
  tel text,
  addr text,
  variety text,
  expected_qty integer DEFAULT 0,
  created_by text,
  created_at timestamptz DEFAULT now()
);

-- 콘테이너 대장 (조합 컨테이너 배출/원물수거/잉여회수)
CREATE TABLE containers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date date NOT NULL,
  farm_name text NOT NULL,
  type text NOT NULL CHECK (type IN ('배출','원물수거','잉여회수')),
  qty integer NOT NULL DEFAULT 0,
  staff text,
  car text,
  note text,
  created_by text,
  created_at timestamptz DEFAULT now()
);

-- 농가 자가 컨테이너
CREATE TABLE own_containers (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date date NOT NULL,
  farm_name text NOT NULL,
  description text,
  in_qty integer NOT NULL DEFAULT 0,
  out_qty integer DEFAULT 0,
  consumed text DEFAULT '진행중',
  return_method text DEFAULT '미정',
  return_date date,
  note text,
  created_by text,
  created_at timestamptz DEFAULT now()
);

-- 수거 일정
CREATE TABLE schedules (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  date date NOT NULL,
  farm_name text NOT NULL,
  status text DEFAULT '예정' CHECK (status IN ('예정','완료','취소','연기')),
  expected_qty integer DEFAULT 0,
  actual_qty integer DEFAULT 0,
  car text,
  driver text,
  note text,
  created_by text,
  created_at timestamptz DEFAULT now()
);

-- RLS (Row Level Security) 비활성화 - 사내 전용 앱이므로 간단하게 설정
ALTER TABLE farms ENABLE ROW LEVEL SECURITY;
ALTER TABLE containers ENABLE ROW LEVEL SECURITY;
ALTER TABLE own_containers ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedules ENABLE ROW LEVEL SECURITY;

-- 모든 사용자가 읽기/쓰기 가능하도록 정책 설정 (사내 전용)
CREATE POLICY "allow_all_farms" ON farms FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_containers" ON containers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_own" ON own_containers FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "allow_all_schedules" ON schedules FOR ALL USING (true) WITH CHECK (true);
